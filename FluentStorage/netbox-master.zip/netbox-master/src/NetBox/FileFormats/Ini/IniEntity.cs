﻿namespace NetBox.FileFormats.Ini
{
   abstract class IniEntity
   {
   }
}
